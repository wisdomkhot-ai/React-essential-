import { useState, createContext, useContext } from "react";

const UserContext = createContext();

export default function App() {
  const [user, setUser] = useState("admin");

  return (
    <div>
      <h2>useContext Hook Demo</h2>
      <p>React Context is a way to manage state globally.</p>
      
      <UserContext.Provider value={{user,setUser}}>
        <h1>Hello ${user}!</h1>
        <Component2 /> 
        <Component4 />
      </UserContext.Provider>
    </div>
  );
}

function Component2() {
  return (
    <>
      <h1>Component 2</h1>
      <Component3 />
    </>
  );
}

function Component3() {
  const {user,setUser} = useContext(UserContext);

  return (
    <>
      <h1>Component 3</h1>
      <h2>Hello {user} again!</h2>
    </>
  );
}

function Component4() {
  const {user,setUser} = useContext(UserContext);

  return (
    <>
      <h1>Component 4</h1>
      <h2>Hello {user} again!</h2>
      <input type="text" 
      placeholder="Enter Data" onChange={(e)=>setUser(e.target.value)} />
     
    </>
  );
}
