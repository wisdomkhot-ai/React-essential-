import { useRef } from "react";
import Content from "./Content";

export default function App() {
  const userRef = useRef(null);
  const pwdRef = useRef(null);
  const msgRef = useRef(null);

  function handleSubmit() {
    const un = userRef.current.value;
    const pwd = pwdRef.current.value;
    const msg = msgRef.current;

    if (un == "" || pwd == "") {
      msg.innerText = "Enter Data In All Fields";
      msg.style.color = "red";
    } else if (un == pwd) {
      msg.innerText = "Welcome " + un;
      msg.style.color = "white";
    } else {
      msg.innerText = "Invalid Credentials";
      msg.style.color = "red";
    }
  }
  function handleReset() {
    userRef.current.value = "";
    pwdRef.current.value = "";
    userRef.current.focus();
    msgRef.current.innerText = "";
  }
  return (
    <div className="container">
      <Content title="Login:uncontrolled">
        <input
          className="mt-3"
          ref={userRef}
          type="text"
          placeholder="UserName"
        />

        <input
          className="mt-3"
          ref={pwdRef}
          type="password"
          placeholder="Password"
        />
        <div className="mt-3 mb-3">
          <button onClick={handleSubmit}>Submit</button>&nbsp;
          <button onClick={handleReset}>Reset</button>
        </div>
        <h5 ref={msgRef}></h5>
      </Content>
    </div>
  );
}
