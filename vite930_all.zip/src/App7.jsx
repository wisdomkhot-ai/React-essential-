export default function App() {
  return (
    <div>
      <Greet />
      <Bye />
      <Greet />

    </div>
  );
}

function Greet() {
  return <h2>Welcome</h2>;
}

const Bye=()=><h2>Bye Bye</h2>;

