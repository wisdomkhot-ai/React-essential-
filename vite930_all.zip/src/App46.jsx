import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import Product from "./Product";
import Help from "./Help";
import Details from "./Details";
import TollFree from "./TollFree";
import Premium from "./Premium";

export default function App() {
  return (
    <div className="text-center">
      <h2>My Website</h2>
      <BrowserRouter>
        <Link to="/">Home</Link>&nbsp;
        <Link to="/pro">Products</Link>&nbsp;
        <Link to="/help">Help</Link>&nbsp;
        <hr />
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/pro" element={<Product/>} />
          <Route path="/pro/:id" element={<Details/>} />
          <Route path="/help" element={<Help/>} >
            <Route path="tollfree" element={<TollFree/>} />
            <Route path="premium" element={<Premium/>} />
          </Route>
          <Route path="*" element={<PageNotFound/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

function PageNotFound() {
  return <h2>Page Not Found</h2>;
}
