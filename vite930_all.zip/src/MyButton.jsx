import React from 'react'

export default function MyButton({clicked,title='Demo'}) {
  return (
    <div>
        <button onClick={clicked} 
        className='btn btn-info'>{title}</button>
    </div>
  )
}
