import React from 'react'

export default function Student({id,name='?',age='?'}) {
  return (
    <div>
        <p className='mb-3 bg-primary rounded-pill p-2 text-center w-50 text-white'>
            Student Info: ID: {id} Name: {name} Age: {age}
        </p>
    </div>
  )
}
