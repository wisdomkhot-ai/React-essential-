import { useState } from "react";
import Content from "./Content";

export default function App() {
  const [data, setData] = useState({ nm: "", age: "", city: "" });

  function handleChange(e) {
      setData({...data,[e.target.name]:e.target.value})
  }

  function handleSubmit(e) {
    e.preventDefault();
    alert(data.nm + ' ' + data.age + ' ' + data.city);
  }
  return (
    <div className="container">
      <div className="w-25 bg-info p-2 mt-3 rounded mx-auto">
        <h4 className="text-center">Student Info</h4>
        <hr />
        <form className="form" onSubmit={handleSubmit}>
          <label htmlFor="nm">Name:</label>
          <input
            type="text"
            name="nm"
            id="nm"
            value={data.nm}
            onChange={handleChange}
            className="form-control"
          />

          <label className="mt-2" htmlFor="age">
            Age:
          </label>
          <input 
          type="text" 
          name="age" 
          id="age" 
          value={data.age}
          onChange={handleChange} 
          className="form-control" />

          <label className="mt-2" htmlFor="city">
            City:
          </label>
          <input 
          type="text" 
          name="city" 
          id="city"
          value={data.city}
          onChange={handleChange}  
          className="form-control" />
          <div className="text-center mt-2 ">
            <button onClick={handleSubmit} className="btn btn-primary btn-sm">
              Submit
            </button>
            &nbsp;
            <button type="reset" className="btn btn-warning btn-sm">
              Reset
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
