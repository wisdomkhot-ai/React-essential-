import React from 'react'

export default function App() {
    const sports=['Cricket','Badminton','Hockey','TT','LT','Kabbadi']
    const filter_demo=sports.filter(sport=>sport.includes('i'))
  return (
    <div className='container'>
        <ol>
        {
            sports.map((sport,index)=>(
                <li key={index}>{sport}</li>
            ))
        }
        </ol>
        <p>
            After Filter: {filter_demo.join()}
        </p>
    </div>
  )
}
