import React from "react";
import { useState } from "react";

export default function App() {
  const [c, setC] = useState(true);
  const [cpp, setCpp] = useState(false);
  const [cs, setCS] = useState(false);
  const [java, setJava] = useState(true);
  const [msg, setMsg] = useState("");

  function handleSubmit() {
    var skills = [];
    if (c) skills.push("C");
    if (cpp) skills.push("C++");
    if (cs) skills.push("C#");
    if (java) skills.push("Java");

    if (skills.length == 0) 
        setMsg("Your Skills: None");
    else 
        setMsg("Your Skills:" + skills.join());
  }

  function handleReset() {
    setC(false);
    setCpp(false);
    setCS(false);
    setJava(false);
    setMsg("");
  }

  return (
    <div className="d-flex gap-2 mt-3">
      Select Skillset:
      <input
        type="checkbox"
        checked={c}
        onChange={(e) => setC(e.target.checked)}
        id="chkC"
      />
      <label htmlFor="chkC">C</label>
      <input
        type="checkbox"
        checked={cpp}
        onChange={(e) => setCpp(e.target.checked)}
        id="chkCpp"
      />
      <label htmlFor="chkCpp">C++</label>
      <input
        type="checkbox"
        checked={cs}
        onChange={(e) => setCS(e.target.checked)}
        id="chkCS"
      />
      <label htmlFor="chkCS">C#</label>
      <input
        type="checkbox"
        checked={java}
        onChange={(e) => setJava(e.target.checked)}
        id="chkJ"
      />
      <label htmlFor="chkJ">Java</label>
      <button onClick={handleSubmit}>Submit</button>
      <button onClick={handleReset}>Reset</button>
      {msg}
    </div>
  );
}
