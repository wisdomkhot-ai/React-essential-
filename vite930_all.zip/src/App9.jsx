import React from 'react'
import Address from './Address'
import './App.css'

export default function App() {
  return (
    <div>
        <h2 className='mycolor'>You may Contact us at:</h2>
        <Address/>
        <p>Visit in office hours only</p>
        <h3>Thanks</h3>
    </div>
  )
}
