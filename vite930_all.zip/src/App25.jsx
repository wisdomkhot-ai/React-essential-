import { useState } from "react"


export default function App() {
    const [counter,setCounter]=useState(0)
    function handleClick(){
        // setCounter(p=>p+1);
       setCounter(counter + 1)
    }
  return (
    <div>
        <h2>useState Hook Demo</h2>
        Now Counter: {counter}
        <br />
        <button onClick={handleClick}>Count {counter}</button>
    </div>
  )
}
