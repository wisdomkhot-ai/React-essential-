import useFetch from "./useFetch";

export default function App() {
  const [data] = useFetch("https://jsonplaceholder.typicode.com/todos");
  return (
    <div>
      <h2>useFetch Custom Hook</h2>
      <p>You can make your own Hooks!</p>
      {data &&
        data.map((item) => {
          return <p key={item.id}>{item.title}</p>;
        })}
    </div>
  );
}
