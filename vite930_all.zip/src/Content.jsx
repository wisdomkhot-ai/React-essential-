import React from 'react'

export default function Content({children,title=''}) {
  return (
    <div style={{maxWidth:'300px'}} className='rounded p-2 text-center bg-info  mx-auto mt-3'>
       {title!='' && <h2 
        className='rounded bg-primary bordered text-white p-1'>{title}</h2>}
        {children}
    </div>
  )
}
