import './App.css'

export default function App() {
  return (
    <div>
        <h2 className='mycolor'>Hello External CSS</h2>
    </div>
  )
}
