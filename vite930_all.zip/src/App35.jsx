import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'

export default function App() {
const [count1,setCount1]=useState(0)
const [count2,setCount2]=useState(5)

useEffect(()=>{
    console.log('useEffect1 Called...');
}) // run everytime

useEffect(()=>{
    console.log('useEffect2 Called...');
},[])  // called once: component did mount

useEffect(()=>{
    console.log('useEffect3 Called...');
},[count2])  // called when count2 changes: component did update
  return (
    <div className='container'>
        <button onClick={()=>setCount1(count1+1)}>Counter1: {count1}</button>
        &nbsp;
        <button onClick={()=>setCount2(count2+5)}>Counter2: {count2}</button>

    </div>
  )
}
