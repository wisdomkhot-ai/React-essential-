import { useState, useMemo } from "react";

export default function App() {
  const [count, setCount] = useState(0);
  const [counter, setCounter] = useState(0);

  const calculation = 
  useMemo(() => expensiveCalculation(count), [count]);

  return (
    <div>
      <div>
        <h2>useMemoHook Demo</h2>
        <p>The React useMemo Hook returns a memoized value.</p>
        <p>
          the expensive function will only run when count is changed and not
          when counter updates.
        </p>
        <h2>My Counter</h2>
        <button onClick={() => setCounter(counter + 1)}>
          My Counter {counter}
        </button>
      </div>
      <hr />
      <div>
        Count: {count}
        <button onClick={() => setCount(count + 1)}>+</button>
        <h2>Expensive Calculation</h2>
        {calculation}
      </div>
    </div>
  );
}

const expensiveCalculation = (num) => {
  console.log("Calculating...");
  for (let i = 0; i < 1000000000; i++) {
    num += 1;
  }
  return num;
};
