import React from "react";
import Hobby from "./Hobby";

export default function App() {
  const common = ["Reading", "Writing", "Playing"];
  return (
    <div className="container">
      <Hobby name="JK" hobby={["Dance", "Singing", "Drawing"]} />
      <Hobby name="Shreya" hobby={common} hide={true} />
      <Hobby name="Teju" hobby={[...common, "Cooking"]} />
    </div>
  );
}
