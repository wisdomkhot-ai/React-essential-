import React from 'react'

export default function Hobby({name,hobby,hide}) {
 
  
  return (
    <div>
        <h3>{name} Hobbies: {!hide && hobby.join()} {hide && '...'}</h3>
    </div>
  )
}
