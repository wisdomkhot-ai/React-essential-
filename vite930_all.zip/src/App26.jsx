import { useState } from "react";

export default function App() {
  const [data, setData] = useState("");
  return (
    <div className="mx-3">
      <input
        type="text"
        onChange={(e) => setData(e.target.value)}
        placeholder="Enter Data"
      />
     
      {data && <p>You Said: {data}</p>}
    </div>
  );
}
