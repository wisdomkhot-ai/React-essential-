import React from 'react'

export default function Premium() {
  return (
    <div>Premium Contact: 9890100100 (it may cost u charges)</div>
  )
}
