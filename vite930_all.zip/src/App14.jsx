import React from "react";
import Book from "./Book";

export default function App() {
  const details = { id: 1, title: "Let us C", price: 120 };

  return (
    <div className="container">
      <Book details={details} />
    </div>
  );
}
