import './About.css';

export default function About() {
  return (
    <div>
      <h2>About us</h2>
      <h3>Aditya Infotech</h3>
    </div>
  );
}
