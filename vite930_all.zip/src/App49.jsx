import { useState, useEffect, useEffectEvent } from 'react'

export default function App() {
    const [count, setCount] = useState(0)

    const onTick = useEffectEvent(() => {
        console.log("Count :" , count)
        setCount(c => c + 1)
    })

    useEffect(() => {
        const id = setInterval(() => {
            onTick();
        }, 1000)

        return () => clearInterval(id)
    }, [])

  return (
    <div>
        <p>Min. React 19.2 version:  It lets you separate events from Effects.</p>
        <h2>Count : {count}</h2>
    </div>
  )
}

