import React, { useState } from 'react'

export default function App() {
const [adr,setAdr]=useState('Kisan Chowk, Sangli')

  return (
    <div className='container'>
        Enter Address:
        <br />
        <textarea value={adr} onChange={(e)=>setAdr(e.target.value)}></textarea>
        <br />
        <button onClick={()=>alert(adr)}>Submit</button>
    </div>
  )
}

