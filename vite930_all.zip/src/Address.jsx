import styles from './Address.module.css'

export default function Address() {
  return (
    <div className={styles.main}>
      <h2 className={styles.mycolor}> Office Address</h2>
      <h3>Aditya Infotech</h3>
      <p className={styles.bkg}>Kisan Chowk, Sangli</p>
    </div>
  );
}
