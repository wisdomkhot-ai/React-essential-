import React from "react";
import MyButton from "./MyButton";

export default function App() {
  function handleParent() {
    alert("Parent Handle....");
  }

  function handleDemo() {
    alert("Kay Kay");
  }
  return (
    <div className="mx-3 d-flex gap-2">
      <h2>Prop as Function</h2>
      <MyButton clicked={handleParent} />
      <MyButton clicked={handleDemo} title="Greet" />
    </div>
  );
}
