import { configureStore } from '@reduxjs/toolkit';
import counterReducer from './counterSlice';

export const store = configureStore({
  reducer: {
    counter: counterReducer
  }
});


// The Store holds your entire application state. 
// Create a file named src/app/store.js and 
// register your slice reducer