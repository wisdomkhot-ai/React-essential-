
import Dice from './Dice.jsx'

export default function App() {
  const dice=[1,2,3,4,5,6]

  return (
    <div className='container d-flex gap-3 mt-3'>
       {
        dice.map((n)=>(
          <Dice key={n} id={n} />
        ))
       }
    </div>
  )
}
