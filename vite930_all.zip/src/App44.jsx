import React, { useState, useCallback } from "react";

// Child component that receives a function prop
const Button = React.memo(({ clicked, text }) => {
  console.log(`${text} button rendered`);
  return <button onClick={clicked}>{text}</button>;
});

// Parent component with useCallback
export default function App() {
  const [count1, setCount1] = useState(0);
  const [count2, setCount2] = useState(0);
 
  // These functions are memoized and only recreated when dependencies change
  const handleClick1 = useCallback(() => {
  console.log("handleClick1 rendered");

    setCount1(count1 + 1);
  }, [count1]);

  const handleClick2 = useCallback(() => {
  console.log("handleClick2 rendered");

    setCount2(count2 + 1);
  }, [count2]);

  console.log("Parent rendered");
  return (
    <div>
      <h2>useCallback Hook Demo</h2>
      <p>The useCallback Hook is used to memoize a callback function.</p>
      <p>Count 1: {count1}</p>
      <p>Count 2: {count2}</p>
      {/* HOC=High Order Component */}
      <Button clicked={handleClick1} text="Button 1" />&nbsp;
      <Button clicked={handleClick2} text="Button 2" />
       </div>
  );
}
