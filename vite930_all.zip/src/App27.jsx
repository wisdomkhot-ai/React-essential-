import React from "react";
import { useState } from "react";

export default function App() {
  const [gender, setGender] = useState("");
  const [msg, setMsg] = useState("");

  function handleSubmit() {
    if (gender === "m") 
        setMsg("Hello Sir");
    else if (gender === "f") 
        setMsg("Hello Mam");
    else 
        setMsg(<b><i className='text-danger'>Please Select Gender</i></b>);
  }

  return (
    <div className="container d-flex gap-2">
      Select Gender:
      <input type="radio" onChange={(e) => setGender("m")} name="g" id="optM" />
      <label htmlFor="optM">Male</label>
      <input type="radio" onChange={(e) => setGender("f")} name="g" id="optF" />
      <label htmlFor="optF">Female</label>
      <button onClick={handleSubmit}>Submit</button>
      {msg}
    </div>
  );
}
