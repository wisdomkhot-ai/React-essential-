import React from 'react';

// 1. Define the Higher-Order Component
// It accepts a component (WrappedComponent) as an argument
function withRedBorder(WrappedComponent) {
  // It returns a new functional component
  return function EnhancedComponent(props) {
    return (
      <div className='border border-2 border-danger rounded bg-info p-2 mt-3 w-50 text-center' >
        {/* Pass through all existing props to the original component */}
        <WrappedComponent {...props} />
      </div>
    );
  };
}

// 2. Create a basic component
function Profile({ name }) {
  return <h2>User Profile: {name}</h2>;
}

// 3. Enhance the component using the HOC
const ProfileWithBorder = withRedBorder(Profile);

// 4. Use it inside your main App
export default function App() {
  return (
    <div className='container'>
      {/* Normal component */}
      <Profile name="Teju" />
      <p>A Higher-Order Component (HOC) is a function that 
        takes a component as an argument and returns a new, 
        enhanced component</p>
      {/* Enhanced component with a red border */}
      <ProfileWithBorder name="JK" />
    </div>
  );
}
