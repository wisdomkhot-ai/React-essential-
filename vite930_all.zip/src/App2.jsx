const App = () =><h2>Hello Again Again</h2>
  

// const App = () => {
//   return <h2>Hello Once Again</h2>;
// };

// function App(){
//     return <h2>Hello Again</h2>
// }

export default App;
