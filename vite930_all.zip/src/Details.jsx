import { useNavigate, useParams } from "react-router-dom"

export default function Details() {
    const{id}=useParams();
    const navigate=useNavigate();

  return (
    <div>
        <h2>Product Details PID: {id}</h2>
       
        <button onClick={()=>navigate('/pro')}>Back To Products</button>
    </div>
  )
}
