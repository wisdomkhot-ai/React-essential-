import React from "react";
export default function App() {
  let msg = "hello";
  const bye = <p>Bye Bye</p>;
  const list = (
    <>
      <ol>
        <li>sac</li>
        <li>dac</li>
      </ol>
      <b>ok</b>
    </>
  );

  return (
    <>
      <div>Hello React App - {msg} </div>
      <h2>You says {msg}</h2>
      <hr />
      {bye}
      {list}
    </>
  );
}
