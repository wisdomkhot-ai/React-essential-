import React from "react";

export default function App() {
  const players = [
    { name: "sac", age: 10 },
    { name: "dac", age: 12 },
    { name: "qac", age: 18 },
    { name: "hac", age: 16 },
    { name: "kac", age: 15 },
    { name: "lac", age: 17 },
  ];
  const team1 = players.filter((player) => player.age <= 15);

  return (
    <div className="mx-3">
      <h2>Players Below Age 15</h2>
      {team1.map((p, index) => (
        <p key={index}>{p.name}</p>
      ))}

      <h2>Players Above Age 15</h2>
      {players.map((p, index) => (
        (p.age>15) && <p key={index}>{p.name}</p>
      ))}
    </div>
  );
}
