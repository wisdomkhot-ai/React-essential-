import {Link} from 'react-router-dom'


export default function Product() {
  return (
    <div className='w-25 mx-auto'>
        <h2>Products</h2>
        <ol>
            <li><Link to='/pro/1'>Product 1</Link></li>
            <li><Link to='/pro/2'>Product 2</Link></li>
            <li><Link to='/pro/3'>Product 3</Link></li>
        </ol>
    </div>
  )
}
