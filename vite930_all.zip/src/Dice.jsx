// This creates a mapping of all matching files in the directory
const diceImages = import.meta.glob('./assets/*.png', { eager: true });

export default function Dice({ id }) {
  // Find the matching path in the glob object
  const imagePath = `./assets/dice${id}.png`;
  const src = diceImages[imagePath]?.default;

  return src ? <img src={src} alt="Dice" /> : <span>Image not found</span>;
}
