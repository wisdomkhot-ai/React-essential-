export default function App() {
  function handleChange(e) {
    console.log(e.target.value);
  }

  function handleSubmit() {
    alert("Submitted");
  }
  return (
    <div className="mx-3">
      <h2>Events Demo</h2>
      <input type="text" onChange={handleChange} 
      placeholder="Enter Name" />
      <button onClick={handleSubmit}>Submit</button>
      <button onClick={()=>alert('hi there')}>Greet</button>

    </div>
  );
}
