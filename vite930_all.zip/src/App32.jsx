import Content from "./Content";

export default function App() {

    function handleSubmit(e){
        e.preventDefault()
            alert('Form Submitted....')
    }
  return (
    <div className="container">
      <div className="w-25 bg-info p-2 mt-3 rounded mx-auto" >
        <h4 className="text-center">Student Info</h4><hr />
        <form className="form" onSubmit={handleSubmit}>
          <label  htmlFor="nm">Name:</label>
          <input type="text" id="nm" className="form-control" />

          <label className="mt-2" htmlFor="age">Age:</label>
          <input type="text" id="age" className="form-control" />

          <label className="mt-2" htmlFor="city">City:</label>
          <input type="text" id="city" className="form-control" />
          <div className="text-center mt-2 ">
             <button className="btn btn-primary btn-sm">Submit</button>&nbsp;
          <button type='reset' className="btn btn-warning btn-sm">Reset</button>
          </div>      
        </form>
      </div>
    </div>
  );
}
