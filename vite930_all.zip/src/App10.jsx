import React from 'react'

export default function App() {
  return (
    <div className='container mt-5'>
        <h2>Bootstrap Enabled</h2>
        <button className='btn btn-primary'>Demo</button>
        &nbsp;
        <a href="http://www.adityainfo.xyz" 
        className='btn btn-secondary'>My Site</a>
    </div>
  )
}
