import React from "react";
import { Link, Outlet } from "react-router-dom";

export default function Help() {
  return (
    <div>
      <h2> You May Use Below Helplines: </h2>
      <Link to="tollfree">TollFree</Link>&nbsp;
      <Link to="premium">Premium</Link>&nbsp;
      <hr />
      <Outlet />
    </div>
  );
}
