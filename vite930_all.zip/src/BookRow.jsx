import React from "react";

export default function BookRow({ details }) {
  const flag = details.available;
  return (
    <>
      {flag && (
        <tr>
          <td>{details.id}</td>
          <td>{details.title}</td>
          <td>&#8377;{details.price}/-</td>
        </tr>
      )}
    </>
  );
}
