export default function App() {
  const spread_demo = (p1, p2, p3) => `p1=${p1} p2=${p2} p3=${p3}`;

  const rest_demo = (...items) => items;

  const team1 = ["sac", "dac"];
  const team2 = ["wac", "qac"];
  const both = ["tac", ...team1, ...team2];

  const arr = ["one", "two", "three", "four", "five"];
  const [a, b, ...rest] = arr; // destructuring

  const [r, g] = ["red", "green"]; // destructuring
  const clr = { color: `${g}` };
  return (
    <div>
      <h2 style={{ color: `${r}` }}>
        Spread Operator: {spread_demo(..."abc")}
      </h2>
      <h2>Rest Operator: {rest_demo("X", "Y", "Z")}</h2>
      <h2 style={clr}>Team: {both.join()}</h2>
      <h2>a={a} b={b} rest={rest.join("-")}</h2>
    </div>
  );
}
