import BookRow from "./BookRow";

export default function App() {
  const books = [
    { id: 1, title: "Let us C", price: 120, available:false },
    { id: 2, title: "OOP  with C++", price: 200, available:true },
    { id: 3, title: "MERN", price: 180, available:true  },
    { id: 4, title: "Learn Python", price: 220, available:false  },
    { id: 5, title: "Explore Cloud", price: 420, available:true },
  ];

  return (
    <div className="container">
      <h2>Book List in Stock</h2>
      <table className="table table-hover table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>TITLE</th>
            <th>PRICE</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <BookRow key={book.id} details={book} />
          ))}
        </tbody>
      </table>
    </div>
  );
}
