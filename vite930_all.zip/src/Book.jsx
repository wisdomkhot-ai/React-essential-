
export default function Book({ details }) {
  return (
    <div className="bg-info rounded p-2 w-75 mt-3">
      ID: {details.id} Title: {details.title} Price: {details.price}
    </div>
  );
}
