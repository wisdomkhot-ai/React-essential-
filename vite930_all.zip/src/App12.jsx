import React from 'react'
import Student from './Student'

export default function App() {
  return (
    <div className='container'>
        <Student id={1} name='sac' age='12' />
        <Student id={2} name='dac' age='13' />
        <Student id={3} name='wac' age='11' />
        <Student id={4} name='qac'  />


    </div>
  )
}
