import React from 'react'
import Content from './Content'

export default function App() {
  return (
    <div>
        <Content title='Notice'>
            <h4>About Attendance</h4>
            <p>Attend Class Regularly</p>
            <h5>Thanks</h5>
        </Content>
        <Content>
            <p>OK tata bye bye</p>
            Visit Again
        </Content>
    </div>
  )
}
