import Book from "./Book";

export default function App() {
  const books = [
    { id: 1, title: "Let us C", price: 120 },
    { id: 2, title: "OOP  with C++", price: 200 },
    { id: 3, title: "MERN", price: 180 },
    { id: 4, title: "Learn Python", price: 220 },
    { id: 5, title: "Explore Cloud", price: 420 },
  ];
  return (
    <div className="container">
      <h2>Book List</h2>
      {books.map((book) => (
        <Book key={book.id} details={book} />
      ))}
    </div>
  );
}
