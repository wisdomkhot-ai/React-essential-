import logo from "./assets/react.svg";
export default function App() {
  const mycolor = {
    color: "red",
    backgroundColor: "pink",
    maxWidth: "200px",
    margin:'auto'
  };

  return (
    <div style={{ backgroundColor: "steelblue", textAlign: "center" }}>
      <h2 style={mycolor}>Lets color it</h2>
      <img src={logo} alt="React Logo" />
      <h3 style={mycolor}>Wow...</h3>
    </div>
  );
}
