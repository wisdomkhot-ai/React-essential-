import React from "react";
import { useRef } from "react";
import { useState } from "react";

export default function App() {
  const [data, setData] = useState("kay kay");
  return (
    <div className="container bg-primary text-white">
      <h2>State Uplifting</h2>
      {data}
      <ChildComp update={setData} />
    </div>
  );
}

function ChildComp({ update }) {
  const txtRef = useRef();
  return (
    <div className="bg-info w-50 p-2">
      <input type="text" ref={txtRef} placeholder="Enter Data" />
      <button onClick={() => update(txtRef.current.value)}>Submit</button>
    </div>
  );
}
