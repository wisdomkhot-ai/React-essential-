import useFetch from "./useFetch";

export default function App() {
  const [data] = useFetch("http://localhost:3000/users");
  return (
    <div>
      <h2>useFetch Custom Hook</h2>
      <p>You can make your own Hooks!</p>
      {data &&
        data.map((item) => {
          return <p key={item.id}>{item.name}</p>;
        })}
    </div>
  );
}
