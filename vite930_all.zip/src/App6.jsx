export default function App() {
  const logged = false;

  return (
    <div>
      {/* conditoinal rendering */}
      {logged === true ? <h2>Welcome User</h2> : <h2>Access Denied</h2>}

      <hr />
      {!logged && <h2>Please log in....</h2>}
    </div>
  );
}
