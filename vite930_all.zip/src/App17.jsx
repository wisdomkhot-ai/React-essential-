import Book from "./Book";

export default function App() {
  const books = [
    { id: 1, title: "Let us C", price: 120 },
    { id: 2, title: "OOP  with C++", price: 200 },
    { id: 3, title: "MERN", price: 180 },
    { id: 4, title: "Learn Python", price: 220 },
    { id: 5, title: "Explore Cloud", price: 420 },
  ];
  const images = import.meta.glob("./assets/*.png", { eager: true });
  return (
    <div className="container">
      <h2>Book List</h2>
      <table className="table table-hover table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>TITLE</th>
            <th>PRICE</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
