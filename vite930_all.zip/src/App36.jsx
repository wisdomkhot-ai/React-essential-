import { useState, useEffect } from "react";

export default function App() {
    const [count, setCount] = useState(0);
    
    useEffect(() => {
      const timer = setInterval(() => {
        setCount((prev) => prev + 1);
      }, 1000);
     
      // cleanup: unmount
      return()=> clearInterval(timer) 
      
    }, []);  // run once
  
  return (
    <div className="container">
        <h3>I've rendered {count} times!</h3>
    </div>
  )
}
