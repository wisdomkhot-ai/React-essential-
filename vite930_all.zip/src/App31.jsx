import React from 'react'
import { useState } from 'react'

export default function App() {
    const [options,setOptions]=useState([])
    function handleChange(e){
        const items=[...e.target.selectedOptions]
        const values = items.map(item=>item.value)
        setOptions(values)     
    }
    
  return (
    <div className='container'>
        Select Hobby:
       <br /> {/* break  */}
        <select multiple={true} size={5} onChange={handleChange}>
            <option value="Reading">Reading</option>
            <option value="Writing">Writing</option>
            <option value="Coding">Coding</option>
        </select>
        {options.join()}
    </div>
  )
}
