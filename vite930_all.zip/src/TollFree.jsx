import React from 'react'

export default function TollFree() {
  return (
    <div>TollFree Contact: 420420</div>
  )
}
