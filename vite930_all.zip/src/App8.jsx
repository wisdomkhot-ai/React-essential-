import React from 'react'
import About from './About'
import Contact from './Contact'

export default function App() {
  return (
    <div>
        <About/>
        <h2>Visit Us</h2>
        <Contact/>
    </div>
  )
}
