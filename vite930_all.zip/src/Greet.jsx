import React from 'react'

export default function Greet(props) {
    const name=props.name;
    const bg=props.bg;

  return (
    <div>
        <h2 
        style={{backgroundColor:`${bg}`}} 
        className=' 
        mt-3 
        p-2 
        w-25 
        mx-auto 
        rounded-pill'>Hello {name}</h2>
    </div>
  )
}
