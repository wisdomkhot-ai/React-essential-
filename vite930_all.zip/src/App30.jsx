import React from "react";
import { useState } from "react";

export default function App() {
  const [city, setCity] = useState("Pune");

  return (
    <div className="container">
      <select value={city} onChange={(e)=>setCity(e.target.value)}>
        <option value="">Select City</option>
        <option value="Sangli">Sangli</option>
        <option value="Pune">Pune</option>
        <option value="Kolhapur">Kolhapur</option>
      </select>
      &nbsp;
      {city}
    </div>
  );
}
