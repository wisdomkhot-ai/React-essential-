import React from "react";

export default function App() {
  let counter = 0;
  const handleClick = () => {
    counter += 1;
    console.log(counter);
  };
  return (
    <div className="mx-3">
      <button onClick={handleClick}>Count {counter}</button>
    </div>
  );
}
