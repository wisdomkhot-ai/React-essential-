import { createSlice } from '@reduxjs/toolkit';

// A Slice bundles your initial state, 
// reducer functions, and actions into one clean file.


const counterSlice = createSlice({
  name: 'counter',
  initialState: { value: 0 },
  reducers: {
    increment: (state) => {
      // Redux Toolkit uses Immer under the hood, allowing "mutating" syntax safely
      state.value += 1;
    },
    decrement: (state) => {
      state.value -= 1;
    },
    incrementByAmount: (state, action) => {
      state.value += action.payload;
    }
  }
});

// Export the auto-generated action creators
export const { increment, decrement, incrementByAmount } = counterSlice.actions;

// Export the reducer to use in the store
export default counterSlice.reducer;
