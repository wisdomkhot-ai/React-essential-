import React from "react";

export default function App() {
  const data = "Hello";

  return (
    <div className="bg-secondary text-white">
        <h3>Props Drilling</h3>
      Parent App {data}
      <Comp1 data={data} />
    </div>
  );
}

function Comp1({data}) {
  return <div className="bg-primary">This is comp1...
  <Comp2 data={data}/>
  </div>;
}

function Comp2({data}) {
    return <div className="bg-warning">This is comp2...
    <Comp3 data={data}/>
    </div>;
  }

  function Comp3({data}) {
    return <div className="bg-info text-dark">This is comp3...{data}</div>;
  }