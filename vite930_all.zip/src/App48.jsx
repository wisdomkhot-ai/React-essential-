import { useLayoutEffect, useState, useRef } from 'react'

export default function App() {
  const boxRef = useRef(null)

  useLayoutEffect(() => {
         const el = boxRef.current  
      
         const width = el.offsetWidth;

         el.style.transform = `translateX(${width}px)`

  }, [])

return (
      <div ref={boxRef} 
          style={{ 
                  padding: "30px", 
                  background:"skyblue", 
                  transition: "3s"
                
              }}>
                <p>Measuring layout before the browser repaints the screen </p>
          Animated Box
      </div>
)
}

