import React from 'react'
import Greet from './Greet'

export default function App() {
  return (
    <div className='text-center'>
        <Greet name='Teju' bg='skyblue'/>
        <Greet name='JK' bg='pink'/>

    </div>
  )
}
