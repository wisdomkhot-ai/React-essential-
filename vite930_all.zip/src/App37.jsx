import { useState } from "react";
import { useEffect } from "react";

export default function App() {
  const [todos, setTodos] = useState([]);
  useEffect(() => {
    getTodos();
  }, []);

  async function getTodos() {
    const url = "https://jsonplaceholder.typicode.com/todos";
    const response = await fetch(url);
    const data = await response.json();
    setTodos(data);
  }
  return (
    <div className="container">
      <h2>WebAPI Read Demo</h2>
      <ol>
        {todos.map((todo) => (
          <li key={todo.id}>{todo.title}</li>
        ))}
      </ol>
    </div>
  );
}
