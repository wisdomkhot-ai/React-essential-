
export default function Contact() {
  return (
    <div>
        <h2>We will Contact Soon...</h2>
        <h3>Hope and Wait</h3>
    </div>
  )
}
